Validations Performed
-----------------------------
Open the App
Click on the Amazon Icon
Click on Skip login (Unable to login as an email notification is being recieved asking me to authenticate login)
Search for the product--> The product to be searched is fetched from excel file
Select a random search option from the search list
Select a random product from searched product list
Fetch the product details
click on add to cart
Navigate to cart and validate the product details
Click on checkout button (Unable to proceed further as asked for login and Unable to login as an email notification is being recieved asking me to authenticate login)


Note: Reports are available in Reports> TestResult.html