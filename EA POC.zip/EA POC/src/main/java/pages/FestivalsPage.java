package pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import utils.Reporting;
import utils.Utility;

public class FestivalsPage extends Utility{

	String festivalnameList="//app-festivals//ol/li";
	String bandname="//li[text()=' __fest__ ']//ul/li";
	
	public void validateFestivalList(Reporting report)
	{
		waitForElementToBeClickable("xpath", festivalnameList);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		List<WebElement> festivalList = new ArrayList<>();
		festivalList.addAll(driver.findElements(By.xpath(festivalnameList)));
		List<String> festivName= new ArrayList<>();
		Properties prop =loadPropertyFile(System.getProperty("user.dir")+"//src//main//resources//PropertyFiles//festival.properties");
	
		for (WebElement el : festivalList) {
			festivName.add(el.getText());
		}
		  
		 Set<Object> set = prop.keySet();
		 System.out.println(festivName);
		 for(Object o: set){
			 String key = (String)o;
			 String value=prop.getProperty(key);
			 key=key.replaceAll("_", " ");
			 if(value.length()>0)
			 {
				 key=key+"\n"+value;
			 }
			 if(festivName.contains(key))
			 {
				report.extentReportPass("String compared successfully "+key+" is present in UI and in data file");
			 }
			 else
			 {
				 report.extentReportFail("String comparison failed "+key+" is not present in UI");
				Assert.assertTrue(false, "String comparison Failed");
			 }
		 }	
		
		
	}
	
	public void validateBandNameWithFestival(Reporting report)
	{
		waitForElementToBeClickable("xpath", festivalnameList);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Properties prop =loadPropertyFile(System.getProperty("user.dir")+"//src//main//resources//PropertyFiles//festival.properties");
		
		 Set<Object> set = prop.keySet();
		
		 for(Object o: set){
			 String key = (String)o;
			 String value=prop.getProperty(key);
			 key=key.replaceAll("_", " ");
			 bandname.replaceAll("__fest__", key);
			 stringEquals(getText(bandname, "xpath", report), value, report);
		 }
	}
	
}
