package test;

import java.io.IOException;
import java.net.MalformedURLException;

import org.apache.xalan.xsltc.dom.ExtendedSAX;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.MediaEntityBuilder;

import pages.FestivalsPage;

import utils.Reporting;
import utils.Utility;

public class SampleTest extends Utility{

	Reporting extentReport;

	/*
	 * Description: Constructor for initializing the class variables and the parent class
	 * Created By: Anand Mohandas 
	 */

	public SampleTest() {
		super();
	}

	/*
	 * Description: Before test method to initialize the reporting file
	 * Created By: Anand Mohandas 
	 */

	@BeforeTest
	public void testready() 
	{
		SampleTest sample=new SampleTest();

		//Reporting for the Test 

		extentReport=new Reporting();
		extentReport.extentReportInit();
		

	}

	/*
	 * Description: Test scenario to validate Festival Names displayed in UI is the same as the property file
	 * Created By: Anand Mohandas 
	 */
	
	@Test(enabled = true)
	public void validateFestivals()
	{
		extentReport.logger=extentReport.report.createTest("Validate Festival Names in UI with Property File or DB");

		//Initialize the driver
		driverInit(extentReport);
		new FestivalsPage().validateFestivalList(extentReport);
	}
	
	/*
	 * Description: Test scenario to validate band name under each Festival Names displayed in UI against property file
	 * Created By: Anand Mohandas 
	 */
	@Test
	public void validateBandNameWithFestival()
	{
		extentReport.logger=extentReport.report.createTest("Validate Band Names of each festival in UI against Property File or DB");

		//Initialize the driver
		driverInit(extentReport);
		new FestivalsPage().validateFestivalList(extentReport);
	}
	
	

	/*
	 * Description: After Method to tear down the driver and check execution status
	 * Created By: Anand Mohandas 
	 * Attribute: result - Class object of ITestResult to fetch the overall execution status
	 */

	@AfterMethod
	public void afterMethod(ITestResult result)
	{

		if(ITestResult.FAILURE==result.getStatus())
		{
			extentReport.extentReportFail(result.getThrowable().getMessage());
			//extentReport.logger.fail(result.getThrowable().getMessage(),MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
		}
		driver.quit();
		extentReport.report.flush();
	}
}
